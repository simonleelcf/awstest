module.exports = {
  apps: [
    {
      name: "my-app",
      script: "./src/index.js",
    },
  ],
};
